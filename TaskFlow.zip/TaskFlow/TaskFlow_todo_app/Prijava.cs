﻿using Fanya_todo_app;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaskFlow_todo_app
{
    public partial class Prijava : Form
    {
        public Prijava()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuLabel1_Click(object sender, EventArgs e)
        {

        }

        private void btnPrijava_Click(object sender, EventArgs e)
        {
            string username = txtkrIme.Text;
            string password = txtLozinka.Text;

            if (username == "admin" && password == "admin123")
            {
                MessageBox.Show("Prijava uspješna! Dobrodošli, Administrator.");

                this.Hide();
                FrmMain FrmMain = new FrmMain(true);
                FrmMain.Show();
            }
            else if (username == "user" && password == "user123")
            {
                MessageBox.Show("Prijava uspješna! Dobrodošli, korisniče.");
                this.Hide();
                FrmMain FrmMain = new FrmMain(false);
                FrmMain.Show();
            }
            else
            {
                MessageBox.Show("Pogrešno korisničko ime ili lozinka.", "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
