﻿using ProjectRoy.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ServiceStack.OrmLite;
using Fanya_todo_app.DataAccess.Models;
using Bunifu.Utils;
using Kimtoo.BindingProvider;

namespace Fanya_todo_app
{
    public partial class FrmMain : Form
    {
        private DateTime _date = DateTime.Today;
        private string _category = "All";
        private string _status = "All";
        private bool isAdmin;

        public FrmMain()
        {
            InitializeComponent();

            calendar1.Value = DateTime.Today;
            ReloadCategories();

            var db = DbContext.GetInstance();
            grid.OnEdit<TodoItem>((r, c) => db.Save(r) || true);
            grid.OnDelete<TodoItem>((r, c) => db.Delete(r) >= 0);
            grid.OnError<TodoItem>((r, c) => bunifuSnackbar1.Show(this, DbContext.Exception.Message, Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error));
        }

        public FrmMain(bool isAdmin)
        {
            InitializeComponent();
            this.isAdmin = isAdmin;
            ConfigureUI();
        }
        private void ConfigureUI()
        {
            if (isAdmin)
            {

                btnAdminOnly.Visible = true;
                lblRole.Text = "Administrator";
            }
            else
            {

                btnAdminOnly.Visible = false;
                lblRole.Text = "Korisnik";
            }
        }

        private void ReloadCategories()
        {
            var db = DbContext.GetInstance();

            
            List<string> catItems = new List<string>();
            catItems.Add("All");

            foreach (var category in db.Select<Category>())
                catItems.Add(category.CategoryName);

            optCat.Items = catItems.ToArray();
        }

        private void ReloadData()
        {
            var db = DbContext.GetInstance();

            var data = db.Select<TodoItem>();
            data = data.Where(r => this._date >= r.StartDate.Date && this._date <= r.EndDate.Date).ToList();

            if (this._category != "All")
                data = data.Where(r => r.CategoryId == Category.GetCategoryByName(this._category).id).ToList();

            if (this._status != "All")
                data = data.Where(r => r.Done == (this._status == "Complete")).ToList();

            grid.Bind(data);
        }

        private void FrmMain_Shown(object sender, EventArgs e)
        {
            menu.Width = 306;
            ReloadData();
        }

        private void calendar1_ValueChanged(object sender, EventArgs e)
        {
            this._date = calendar1.Value;
            ReloadData();
        }

        private void optCat_OnSelectionChange(object sender, EventArgs e)
        {
            this._category = sender.ToString();
            btnAdd.Visible = this._category != "All";
            ReloadData();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            ReloadData();
            grid.SearchRows(txtSearch.Text.Trim());
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var db = DbContext.GetInstance();

            var newTask = new TodoItem()
            {
                CategoryId = Category.GetCategoryByName(this._category).id,
            };

            db.Save(newTask);

            grid.Bind(newTask, 1);
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (grid.CurrentRow.Tag == null) return;

            grid.DeleteRow<TodoItem>(grid.CurrentRow);
        }

        private void menu_OnItemSelected(object sender, string path, EventArgs e)
        {
            if (path == "Manage Categories")
            {
                

                Backdrop.Show(new FrmCategories(), this);

                ReloadCategories();
                return;
            }

            this._status = path.ToString();
            ReloadData();
        }

        private void btnAdminOnly_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Dobrodošli, Administrator.");
        }
    }
}